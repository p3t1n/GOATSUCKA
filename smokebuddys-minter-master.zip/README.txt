##################################################
# Smoke Buddys DAO Minter @ Runes Ordinals       #
# Autor: Ic3 @ SmokeBuddys DAO                   #
# Usage: bash smokebuddysminter                  #
##################################################
## Support us if you profit xD 
## BTC: bc1puezkfpq7eea6whzrh68qmhvw9gmxynwpe8mr5w509ycqcn3y64hq9ywjrn 

Para usar este script, basta salvá-lo em qualquer diretório linux e ter o ord-018.2 instalado na pasta /root/ord-018.2/
dar permissões chmod +x smokeminter;
Rodar o minter usando comando ./smokeminter
Seja Feliz :D

--------------------------------------------

To use this script, simply save it in any linux directory and have ord-018.2 installed in the /root/ord-018.2/ folder.
give chmod +x smokeminter permissions;
Run the minter using the command ./smokeminter
Be happy :D




